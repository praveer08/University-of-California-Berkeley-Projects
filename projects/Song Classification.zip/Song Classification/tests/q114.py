test = {
  'name': 'Question 1.1.4',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> most_shortened
          'international'
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
