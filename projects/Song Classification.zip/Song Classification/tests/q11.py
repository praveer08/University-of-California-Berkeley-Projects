test = {
  'name': '1.1',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> float(expected_row_sum)
          1.0
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
