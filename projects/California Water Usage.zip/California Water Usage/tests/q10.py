test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> income_by_zipcode.num_columns
          111
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> income_by_zipcode.num_rows
          1483
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
