test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> non_death_penalty_murder_rates.num_rows
          264
          >>> non_death_penalty_murder_rates.labels
          ('State', 'Year', 'Population', 'Murder Rate')
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
